# Placement-cell-management-system
It is a java application developed on Netbeans IDE with MySQL as backend. The project focuses on providing an easy and reliable platform for all the companies visiting the college for placement.
When the companies visit the college to recruit students, the idea is to help the company with basic information of students and they can add their eligibility criteria and schedule.
And with the student's point of view, they need to know about the company schedule and the role for which they are hiring.
All these tasks will be handled by placement & training officer of the respective college and there may be communication gap or delay.
Thus this proposed system forms a direct bridge between the students and company to communicate effectively.

Tools-
IDE : Netbeans
DATABASE : MySQL
LANGUAGE : JAVA
